class BoardingCard {
	
	private $ride_number;
	private $date;
	privarte $start_journey;
	
	
}